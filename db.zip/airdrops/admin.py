from django.contrib import admin


from .models import Airdrop

admin.site.register(Airdrop)

